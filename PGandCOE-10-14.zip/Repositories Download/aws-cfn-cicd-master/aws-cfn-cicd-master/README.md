# CI-CD pipeline -  Jenkins, Artifactory, GitHub enterprise AWS CloudFormation templates

## Need to be updated

This project documents and delivers a reproducible pattern to setup a Continous Integration-Continous Deployment (CI-CD) pipeline to install Jenkins client master, JFROG Artifactory, GitHub enterprise.

In simple terms, a __CI-CD__ pipeline provides development teams the ability to commit their code to a source code repository, automatically build on every commit, test the build, on successful build binary __integrate__ the code with master repo  and __deploying__ the successful build binary in production environment for consumption by the end customers.

At a minimum for a __CI-CD__ pipeline, we need the following:
* A source code repository with version control, in our case it is **_GitHub enterprise_** *(hosted on our VPC at this time)*
* A *Continous Integration* engine that in our case is **_CloudBees Jenkins_** along with **_CloudBees Jenkins Operation Center_** for centralized management of multiple Jenkins masters
* A *binary repository* for storing the build binaries, in our case it will be **_JFrog Artifactory_**

In the folders in this repository we will have CloudFormation Templates (CFT) that will help end users create their pipelines with the said tools. Typically, GitHub, CJOC and Artifactory are setup enterprise wide and the CFTs may not be executed regularly. The reason we would like have them written as CFT is to enable to bring it back up if necessary. Each of the lines of business' (LOBs) will have their own Jenkins client masters and as and when the LOB's are on-boarded to PGE AWS cloud framework, they can execute Jenkins CFT to get their pipeline which will integrate with enterprise wide GitHub, CJOC and Artifactory *(subject to change)*

# Getting Started
The templates are created to describe AWS resources and their properties needed for the tool. When you deploy the template it becomes a stack, **[AWS CloudFormation](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/cfn-whatis-concepts.html#w2ab2b5c15b9)**  provisions the resources that are described in your template. 

In this repo, there will be three directories that will hold the templates for **Jenkins** (_jenkins_), **Artifactory** (_artifactory_) and **GitHub** (_ghe_).

##### General deployment of a CFT
* Clone the **[CI-CD _(aws-cfn-cicd)_ ](https://github.com/PGEDigitalCatalyst/aws-cfn-cicd)** repo
* Change directory to the appropriate folder
* **Login** to AWS console, corresponding to your **[account](https://wiki.comp.pge.com/x/LDj6Ag)**
* Select the desired **AWS region**
* Select **Services** from the drop down menu, navigate to **CloudFormation** *(under Management)* 
* Click the **Create Stack** button
* In the **Choose a template** section, **Choose File**, select the **CFT** from the local cloned repo
* Click **Next**
* Give an unique **meaningful** name for the stack
* Fill in the parameters, as required by the chosen tools template *(additional information about parameters in the folders corresponding to the tool)*
* Click **Next**
* The next page page can be left with default parameters, click **Next**
* Review the submission
* Click **Create**
* Once created watch the events
* Wait for **CREATE_COMPLETE** for the requested stack
* Click the **Outputs** tab and notedown the *IP address*.

From your favorite browser open the **ip address** and configure the deployed *tool* to meet your needs

## Tools specific parameters
Tools specific CloudFormation Template parameters will be described in the README notes of each of the tools *(jenkins, artifactory, ghe)* folder.

----
update from outside collaborator

----
###### [MarkDown Reference](https://help.github.com/articles/basic-writing-and-formatting-syntax/)
