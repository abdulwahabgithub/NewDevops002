# CFT for Jenkins single master deployment

The current CloudFormation template creates a single jenkins master on an EC2 instance. The plan is to create a stack in each of the LOB accounts. Once we have a CloudBees Jenkins Operation Center installed, the jenkins master from the LOB will register itself to the CJOC. You may need to create an EFS and ALB before running this template.

# Deploying a jenkins master stack from template
1. Clone this repo

```
git clone https://github.com/PGEDigitalCatalyst/aws-cfn-cicd.git
```
2. Change directory to jenkins
```
cd jenkins
```
3. Select **[jenkins-cft.yml](https://github.com/PGEDigitalCatalyst/aws-cfn-cicd/blob/master/jenkins/jenkins-cft.yml)** for using as template in Create stack
4. Follow the steps listed in [General Stack Deployment](https://github.com/PGEDigitalCatalyst/aws-cfn-cicd/blob/master/README.md#general-deployment-of-a-cft) 
4. Use the parameters shown below as guidance for deploying a Jenkins Master Instance. 
5. The account used in the example screen shot uses __pge-it-nonprod account__, the *VPC, Subnet, SecurityGroup* will change in the account this stack is created.
![jenkins-client-master-stack-input-parameters-screenshot](https://github.com/PGEDigitalCatalyst/aws-cfn-cicd/raw/master/jenkins/jenkins-client-master-stack-input-parameters.png)
6. Click create !
7. Happy **CI/CD** :+1:


