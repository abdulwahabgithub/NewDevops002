By Default; terraform workspace will be non-prod

TO format terraform template after change;
terraform fmt

TO switch environment to production;
terraform workspace show

IF production workspace not found
terraform workspace new prod

TO Switch terraform workspaces
terraform workspace select default

terraform init
terraform  plan    -var-file="terraform.tfvars" --auto-approve
terraform  apply   -var-file="terraform.tfvars" --auto-approve
terraform destroy  -var-file="terraform.tfvars" --auto-approve

terraform  plan    -var-file="terraform_prod.tfvars" --auto-approve
terraform  apply   -var-file="terraform_prod.tfvars" --auto-approve
terraform  destroy -var-file="terraform_prod.tfvars" --auto-approve

curl -k -d "@raisealert-body.json" -H "Content-Type: application/json" -H "x-api-key:"<API_KEY>" -X POST https://0avq3jvkvk.execute-api.us-west-2.amazonaws.com/Dev
