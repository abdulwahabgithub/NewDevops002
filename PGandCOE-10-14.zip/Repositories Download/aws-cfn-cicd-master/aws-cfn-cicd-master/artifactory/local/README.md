CFT for JFROG-Artifactory single master deployment

The current CloudFormation template creates a single Artifactory master on an EC2 instance. The plan is to create a stack in each of the LOB accounts. 

Deploying a Artifactory master stack from template

Clone this repo

git clone https://github.com/PGEDigitalCatalyst/aws-cfn-cicd.git

Change directory to artifactory

cd artifactory

Select jfrog-cft.yml for using as template in Create stack

Follow the steps listed in General Stack Deployment

Use the parameters shown below as guidance for deploying a Atrifactory Master Instance.

The account used in the example screen shot uses pge-it-nonprod account, the VPC, Subnet, SecurityGroup will change in the account this stack is created. jenkins-client-master-stack-input-parameters-screenshot

Click create !

After Creating 

SSH into the EC2 Instance ssh -i key.pem ec2@ipaddress

check the status of artifactory

system artifactory status 

Please stop the service

system artifactory stop

Change directory to conf

cd /opt/jfrog/artifactory/tomcat/conf

Need to edit the server.xml file and change the server port from 8081 to 8080

vi server.xml

edit the port 8081 to 8080 

save and exit the file

Restart artifactory

system artifactory start

check the status 

Hit the ipaddress:8080 from browser.

Wohooo..!! you can see your service Running.
