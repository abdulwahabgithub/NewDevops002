## Instructions: Deploying springboot Kubernetes pod using AWS Code Build and Code Pipeline CI/CD Tools to EKS Cluster


# Prerequisites:
* Required AWS Cloud Formation templates
* EKS Cluster and nodes
* AWS Cloud Formation template to create a SAFE 2.0 compliant AWS ecr repository to store images.
* Have a seperate template for ecr need to launch before ci/cd.
* IAM Role for codepipeline pod deployments

# Launch ecr repo template before ci/cd template:
* https://github.com/pgetech/aws-ci-automation-ref/blob/r4tn/CLOUDCOE-9999/container/ekscodepipeline/ecrrepo.yml

# How you will build it
**Section 1: Setup GitHub for use by Cloud Formation**
* Create a GitHub personal access token to pass it trigger webhook when check-in code.

**Section 2: Deploy the kubernetes Pod through AWS Code Pipeline Infrastructure**
* 1. Run the AWS Cloud Formation Template to create the AWS ecr repository
* 2. Run the AWS Cloud Formation Template to create the AWS code pipeline template.

# Note: when your launching aws cfn template for codepipeline we have parameter called pRoleName this name has to match with aws-auth file which we add a role for codepipeline 
# use this command to check the role name and use same name here.
* kubectl edit -n kube-system configmap/aws-auth

* 3. Run the AWS Cloud Formation Template to create the AWS Code Pipeline, Build Stages.

A springboot application Kubernetes service used in the EKS CI/CD Pipeline module.

The Dockerfile will build that compiles the application and then packages it in a minimal image that pulls from scratch. The size of this Docker image is ~ 88.40 MB.

The buildspec.yml file is used by the AWS CodeBuild stage. In this file, it pulls down kubectl, builds the container image, pushes the image to Amazon ECR and then deploys the change to the Amazon EKS Cluster.

In the kube.yml file, you will find the Kubernetes service, ALB Loadbalancer, Pods and deployment definitions. The file is configured with a LoadBalancer which prompts Kubernetes to launch an internal load balancer using an AWS ELB with new security group.

# Important:
* We need to check security group assign with CIDR Range with any port right now we are using Port 80 (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)

## References
* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

## Authored By
* Rajesh Tadiparthi
