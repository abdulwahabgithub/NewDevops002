# Instructions: This Instructions helps you to deploy a Kubernetes cluster that uses Amazon Elastic Kubernetes Service (Amazon EKS), enabling you to deploy, manage, and scale containerized applications running on Kubernetes on the Amazon Web Services (AWS) Cloud.


# Overview:
Amazon EKS runs the Kubernetes management infrastructure for you across multiple AWS Availability Zones to eliminate a single point of failure. 

You can use the AWS CloudFormation templates included with the Quick Start to deploy an Amazon EKS cluster in your AWS account in about 25 minutes. The Quick Start automates the following:

Deploying Amazon EKS into an existing VPC and Subnets

# EKS Cluster version:
AWS EKS cluster 1.19 version 

Using cloudformation template EKS have issues with tags, control plane logging enabled, private network enabled, Add-on network. we're using lambda function with python script to enable all these tasks for now. when launching cfn template it will takecare of all these. Everytghing is automated.

# Prerequisites:
We need AWS CloudFormation templates as a starting point for your own implementation.

AWS Cloud Formation template to create a SAFE 2.0 compliant EKS Cluster creation.

AWS Cli and Credentials 

## How you will build it

Step1:
## Launch eks template:

* https://github.com/pgetech/aws-ci-automation-ref/blob/r4tn/CLOUDCOE-91/container/ekscluster/eks-cluster.yml

Step2:
# Role based Access:
When we are launching a cluster using a role from our local eks cluster will authenticate with that role. Otherthan this we can't access EKS Cluster first time. We can provide access to the users based on the role arn.

# Docs for eks role access:
* [EKS cluster role based access] (https://docs.aws.amazon.com/eks/latest/userguide/add-user-role.html)

After Launching the cluster using AWS cloudformation template

Step3:
Before joining nodes to the cluster we need to do some configuration stuff for EKS Cluster.

### kubectl install
* curl -o kubectl https://amazon-eks.s3.us-west-2.amazonaws.com/1.18.9/2020-11-02/bin/linux/amd64/kubectl
* curl -o aws-iam-authenticator https://amazon-eks.s3.us-west-2.amazonaws.com/1.18.9/2020-11-02/bin/linux/amd64/aws-iam-authenticator
* chmod +x ./kubectl ./aws-iam-authenticator
* mkdir $HOME/bin
* cp ./kubectl $HOME/bin/kubectl
* cp ./aws-iam-authenticator $HOME/bin
* export PATH=$HOME/bin:$PATH
* echo 'export PATH=$HOME/bin:$PATH' >> ~/.bashrc

# eksctl install
# Linux
* curl --silent --location "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /bin
* eksctl version
# Macos
* /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
* brew tap weaveworks/tap
* brew install weaveworks/tap/eksctl
* brew upgrade eksctl && brew link --overwrite eksctl
* eksctl version

# Important:
* Install AWS Load Balancer Controller this will use when we'are deploying pods and trying to expose an application.

* Follow the instructions below:

* [AWS Load Balancer Controller] https://docs.aws.amazon.com/eks/latest/userguide/aws-load-balancer-controller.html

## References:

* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

* [AWS EKS Cluster Documentation] https://docs.aws.amazon.com/eks/latest/userguide/what-is-eks.html

## Authored By
* Rajesh Tadiparthi
