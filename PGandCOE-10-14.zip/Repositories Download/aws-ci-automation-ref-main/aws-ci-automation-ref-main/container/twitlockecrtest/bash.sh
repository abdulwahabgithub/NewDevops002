#!/bin/sh -xv

echo "alert - ${ALERT_TYPE}"

alerts=$(jq .results[0].vulnerabilityDistribution.${ALERT_TYPE} results.json)

#high
highArr=("high" "critical")
#medium
mediumArr=("medium" "critical" "high")
#low
lowArr=("low" "critical" "high" "medium")
#critical
criticalArr=("critical")

#arrToConsider
if [ "${ALERT_TYPE}" == 'high' ]
  then
    arrToConsider=${highArr[*]}
elif [ "${ALERT_TYPE}" == 'medium' ]
  then
    arrToConsider=${mediumArr[*]}
elif [ "${ALERT_TYPE}" == 'low' ]
  then
    arrToConsider=${lowArr[*]}
elif [ "${ALERT_TYPE}" == 'critical' ]
  then
    arrToConsider=${criticalArr[*]}
fi

#AlertsToConsider
if [ "${alerts}" -gt 0 ]
then
  exit 1
else 
  for i in "${arrToConsider[*]}" 
  do
    otherAlert=$(jq .results[0].vulnerabilityDistribution.${i} results.json)
    if [ "${otherAlert}" -gt 0 ]
    echo "Entering Here"
    then
      exit 1
    fi
  done
fi
docker push $1:$2
echo "docker push"
