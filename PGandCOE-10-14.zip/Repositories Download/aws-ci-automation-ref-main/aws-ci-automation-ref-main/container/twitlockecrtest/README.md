## Instructions: Testing Vulnerabilities For docker images using Twistlockcli AWS Code Build and Code Pipeline and Ecr CI/CD Tools


# Prerequisites:
* Required AWS Cloud Formation templates
* AWS Cloud Formation template to create a SAFE 2.0 compliant Ecr repository to store images.

# create github repo to store docker images before ci/cd template:
* https://github.com/pgetech/aws-ci-automation-ref/tree/main/container/twitlockecrtest

# How you will build it
**Section 1: Setup GitHub for use by Cloud Formation**
* Create a GitHub personal access token to pass it trigger webhook when check-in code.

**Section 2: build the spring boot application and Storing the docker images through AWS Code Pipeline Infrastructure**
* 1. Run the AWS Cloud Formation Template to create the AWS code pipeline template.

The Dockerfile will build that compiles the application and then packages it in a minimal image that pulls from scratch. The size of this Docker image is ~ 88.40 MB.

The buildspec.yml file is used by the AWS CodeBuild stage. In this file, it pulls down and builds the container image, pushes the image to Ecr repo.

# Important:
* We need to check security group assign with CIDR Range with any port right now we are using Port 80 (10.0.0.0/8, 172.16.0.0/12, 192.168.0.0/16)

## References
* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

## Authored By
* Rajesh Tadiparthi
