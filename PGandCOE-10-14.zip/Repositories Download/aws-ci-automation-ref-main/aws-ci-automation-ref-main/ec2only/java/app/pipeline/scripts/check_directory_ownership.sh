#!/bin/bash -xv

# Check for the existence and ownership of the application directory e.g. "/var/opt/spring-boot" and create and set ownership if necessary.

export APP_DIRECTORY="/var/opt/spring-boot"
export USER_OWNERSHIP="spring-boot"
export GROUP_OWNERSHIP="spring-boot"
export CURRENT_USER_OWNERSHIP=""
export CURRENT_GROUP_OWNERSHIP=""

if [ ! -d ${APP_DIRECTORY} ]
then
   mkdir -p "${APP_DIRECTORY}"
   chown -R ${USER_OWNERSHIP}:${GROUP_OWNERSHIP} ${APP_DIRECTORY}
elif [ -d ${APP_DIRECTORY} ]
then
  CURRENT_USER_OWNERSHIP=$(stat -c '%U' $APP_DIRECTORY)
  CURRENT_GROUP_OWNERSHIP=$(stat -c '%G' $APP_DIRECTORY)

  if [ "${CURRENT_USER_OWNERSHIP}" != "${USER_OWNERSHIP}" ]
  then
    chown -R ${USER_OWNERSHIP}:${GROUP_OWNERSHIP} ${APP_DIRECTORY}
  fi

  if [ "${CURRENT_GROUP_OWNERSHIP}" != "${GROUP_OWNERSHIP}" ]
  then
    chown -R ${USER_OWNERSHIP}:${GROUP_OWNERSHIP} ${APP_DIRECTORY}
  fi    
else
  echo "Do nothing...."
fi
