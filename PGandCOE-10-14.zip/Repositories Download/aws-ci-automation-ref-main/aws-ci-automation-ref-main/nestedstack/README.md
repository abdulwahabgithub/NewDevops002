# Instructions: Cloudformation template to  implement nested stack to build and deploy sambuild canary deployments using AWS Code Build and Code Pipeline CI/CD Tools to Lambda serverless Function


## Overview

This is a set of written instructions to set up and configure an AWS Code Pipeline with an AWS Code Build to deploy to Lambda and Api gateway.

## Prerequisites
* **Required AWS Cloud Formation templates**
* AWS Cloud Formation template to create a SAFE 2.0 compliant AWS codepipeline for sambuild Canary Deployment 

## How you will build it
**Section 1: Setup GitHub for use by Cloud Formation**
* Create a GitHub personal access token.  

**Section 2: Deploy the AWS Code Pipeline Infrastructure**

*  1. Run the AWS Cloud Formation Template to create the AWS nested stack it will create Code Pipeline, Build stages for sambuild canary deployments
*  2. After template launch you can check the lambda function alias for versions.
*  3. Api gateway url to test using curl you can findout aws cloudformation console outputs.

**  sample apigate url which i tested placing screenshot here https://github.com/pgetech/aws-ci-automation-ref/blob/r4tn/CLOUDCOE-93/lambda/python/sam/apigatewayendpoint.PNG

## References

* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

## Authored By
* Rajesh tadiparthi - PG&E