# Instructions: Deploying Python/AWS Lambda reference implementation using AWS Code Build and Code Pipeline CI/CD Tools to orchestrate and manage the execution of AWS Code Deploy for Canary type of deployments.


## Overview

This is a set of written instructions to set up and configure an AWS Code Pipeline with an AWS Code Build stage that will create, manage and execute an AWS Code Deploy group for automating this particular use case.

## The AWS Code Pipeline, Build and Deploy Workflow Illustration

![alt text](./AWS_CodePipeline_Lambda_Canary_Deployment.png "AWS Code Pipeline, Build and Deploy Workflow Illustration")

## Prerequisites
* **Required AWS Cloud Formation template**
* AWS Cloud Formation template to create a SAFE 2.0 compliant AWS Code Pipeline and AWS Code Build Stage
* **AWS Cloud Formation Template:** [AWS Code Pipeline/Build Stage CFT](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-78/lambda/python/canary/infra/codepipeline-single-build-AWS-Lambda-CodeDeployWithCfn-WithApproval.yml)
* AWS Code Build Stage build specific YAML
* **Build Spec YAML file :** [AWS Code Build buildspec-cfn.yml](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-78/lambda/python/canary/infra/buildspec-cfn.yml)
* BASH executable script used by AWS Code Build stage to manage and execute the AWS Code Deploy deployment
* **BASH executable script used by AWS Code Build stage:** [AWS Code Pipeline/Build/Deploy CFT](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-78/lambda/python/canary/infra/scripts/aws_lambda_update_appspec.sh)

## The AWS Code Pipeline, Build and Deploy Overall Concepts and Considerations

## How you will build it
**Section 1: Setup GitHub for use by Cloud Formation**
* Create a GitHub personal access token.

**Section 2: Deploy the AWS Code Pipeline Infrastructure**

*  1. Run the AWS Cloud Formation Template to create the AWS Code Pipeline, AWS Code Build and the AWS Code Deploy stage resources.

Note: Ensure that the AWS Lambda function deployment package i.e. ".zip" file is staged on the AWS S3 Bucket
used by AWS Code Pipeline and AWS Code Build prior to executing the AWS Cloud Formation template.

### CFT Input Parameters

Note: The Cloud Formation Stack Name needs to be unique for each separate invocation so that separate and unique resources are provisioned for new pipelines.

The important parameters required to exist in order for this Lambda Function to function properly:

| AWS CFT Parameter      | Description |
| ------------- | ----------- |
| **pS3ArtifactBucketName** | The Name of the AWS S3 Artifact Bucket
| **pLambdaFunctionName** | The Unique Name of The AWS Lambda Function for deployment
| **pGitHubToken** | The User GitHub Access Token for accessing the repo/branch
| **pDebug** | Boolean Value (e.g. 1 or 0 for enabling debugging)
| **pPgeOrderNum** | Organization Project Charge Code Number (e.g. 70036060)
| **pPgeAppId** | Used for tagging assets created by the template.  The AppID tag is the value in 'APP-#### format that represents the AMPS record that this resource is associated with.  The AppID value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeOwner** | Used for tagging assets created by the template.  The Owner tag is the 4 digit Lan ID of the person directly responsible for this resource as recorded in AMPS.  In many cases this is the director or other leader responsible for the application that owns the resource.  The owner value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings.
| **pPgeNotify** | Used for tagging assets created by the template. The Notify tag is the email address of the person or distribution list that would be notified in the event that there are isssues with this resource.  The notify value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeEnv** | Used for tagging assets created by the template.  The Environemnt tag is simply 'DEV', 'TEST', 'QA', or 'PROD' indicating the type of environment that this resource will be created in.  The environment value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeDataClassification** | Used for tagging assets created by the template. Data Classification - Please validate your input value with AMPS
| **pCompliance** | Used for tagging assets created by the template.  Compliance Requirements - Please validate your input value with AMPS
| **pPgeCrisScore** | Used for tagging assets created by the template.  Cyber Risk Impact Score (CRIS) - Please validate your input value with AMPS
| **pPgeBusinessImpact** | Business Impact as reflective of the BIA
| **pPgeLandingZone** | Is this a Cloud CoE Landing Zone resource ("true" or "false")

*  2. The name of the AWS Code Build build specification file is called **buildspec-cfn.yml**

**Section 3: Important aspects of the AWS Code Build Stage**
Note: The AWS Code Build Stage uses the BASH executable script located in the **scripts** sub-folder called **aws_lambda_update_appspec.sh** to do two things:

* 1. Has guard logic to determine if it is an initial deployment to execute the commands to invoke AWS Code Deploy. If it is a re-release invocation of the AWS Code Pipeline it will NOT invoke AWS Code Deploy. If it is an update invocation, it will execute AWS Code Deploy. The guard logic is performing a comparison of the CODEBUILD_RESOLVED_SOURCE_VERSION generated by the GitHub repo/branch between invocations of the AWS Code Pipeline.

* 2. Manages the creation, configuration and execution of the AWS Code Deploy groups if tasked to.

* 3. It dynamically generates and copies to the AWS S3 Bucket used by AWS Code Build the appropriate **appspec.yml** file needed by AWS Code Deploy.


**Section 3: Important aspects of the AWS Code Deploy configuration**

* 1. It is created, configured and executed by the prior AWS Code Build stage using the appropriate AWS CLI commands.

* 2. It supports all of the available deployment configurations for AWS Lambda offered by AWS Code Deploy. For example: **Canary10Percent10Minutes**


## References

* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

* [AWS Code Deploy User Guide](https://docs.aws.amazon.com/codedeploy/latest/userguide/welcome.html)

## Authored By
* Chris Grassi - Cloud Platform Engineer - PG&E
