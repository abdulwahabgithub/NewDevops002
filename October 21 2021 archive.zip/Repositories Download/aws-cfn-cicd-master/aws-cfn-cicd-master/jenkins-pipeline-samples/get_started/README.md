Please follow Step By Step Guide Here.
https://wiki.comp.pge.com/display/CCE/Getting+Started+with+Jenkins+Pipeline