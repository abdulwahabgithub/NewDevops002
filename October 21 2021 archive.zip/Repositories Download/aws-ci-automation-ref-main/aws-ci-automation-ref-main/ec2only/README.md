# Instructions: Deploying Java/Maven reference implementation using AWS Code Build and Code Pipeline CI/CD Tools to AWS EC2 Instances


## Overview

This is a set of written instructions to set up and configure an AWS Code Pipeline with an AWS Code Build and AWS Code Deploy stage to deploy to AWS EC2 instances that are sitting behind an application load balancer and managed by an Auto-Scaling Group.

## Prerequisites
* **Required AWS Cloud Formation templates**
* AWS Cloud Formation template to create a SAFE 2.0 compliant AWS EC2 Launch Configuration, Auto-Scaling Group for Code Deployment and AWS S3 Artifact Bucket
* **AWS ALB/EC2 Launch Configuration/EC2 Auto-Scaling Group, AWS S3 Artifact Bucket Cloud Formation Template:** [AWS ALB/Launch-Config/Auto-Scaling Group CFT](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-71/ec2only/java/infra/codepipeline-EC2-deploy-ALB-ASG-LCFG-S3.yml)
* **AWS Code Pipeline/Build/Deploy Cloud Formation Template:** [AWS Code Pipeline/Build/Deploy CFT](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-71/ec2only/java/app/pipeline/codepipeline-pipeline-build-deploy-for-EC2.yml)

## How you will build it
**Section 1: Setup GitHub for use by Cloud Formation**
* Create a GitHub personal access token.  

**Section 2: Deploy the AWS Code Pipeline Infrastructure**


*  2. Run the AWS Cloud Formation Template to create the AWS ALB, EC2 Launch Configuration EC2 Auto-Scaling Group and AWS S3 Artifact Bucket

Note: You must execute the AWS Cloud Formation Template to create the AWS ALB, EC2 Launch Configuration and EC2 Auto-Scaling Group first
before you do the one for creation of the AWS Code Pipeline, Build and Deploy Stages.

The important parameters required to exist in order for this AWS ALB/ASG/LCFG/EC2 created resources to integrate with the overall infrastructure:

| AWS CFT Parameter      | Description |
| ------------- | ----------- |
| **pS3StagingBucketName** | Obtained from the previous invocation of the CFT for the creation of the AWS S3 Bucket creation
| **pApplicationName** | Very Important: Unique Name to be used across multiple invocations of the AWS Cloud Formation Template to create unique resource names related to this deployment infrastructure
| **pDeploymentTagKey** | Very Important: Used for the EC2 Deployment Tag Name
| **pDeploymentTagValue** | Very Important: Used for the EC2 Deployment Tag Value
| **pExecuteDeployStage** | Very Important: Depending on the value provided, the pipeline skips/continues to deployment stage. Deployment resources will be skipped from provisioning if 'skip' is selected  
| **pPgeOrderNum** | Organization Project Charge Code Number (e.g. 70036060)
| **pPgeAppId** | Used for tagging assets created by the template.  The AppID tag is the value in 'APP-#### format that represents the AMPS record that this resource is associated with.  The AppID value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeOwner** | Used for tagging assets created by the template.  The Owner tag is the 4 digit Lan ID of the person directly responsible for this resource as recorded in AMPS.  In many cases this is the director or other leader responsible for the application that owns the resource.  The owner value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings.
| **pPgeNotify** | Used for tagging assets created by the template. The Notify tag is the email address of the person or distribution list that would be notified in the event that there are isssues with this resource.  The notify value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeEnv** | Used for tagging assets created by the template.  The Environemnt tag is simply 'DEV', 'TEST', 'QA', or 'PROD' indicating the type of environment that this resource will be created in.  The environment value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeDataClassification** | Used for tagging assets created by the template. Data Classification - Please validate your input value with AMPS
| **pCompliance** | Used for tagging assets created by the template.  Compliance Requirements - Please validate your input value with AMPS
| **pPgeCrisScore** | Used for tagging assets created by the template.  Cyber Risk Impact Score (CRIS) - Please validate your input value with AMPS
| **pPgeBusinessImpact** | Business Impact as reflective of the BIA
| **pPgeLandingZone** | Is this a Cloud CoE Landing Zone resource ("true" or "false")

**VERY IMPORTANT**: Please make note of the AWS S3 Artifact Bucket Name, AWS "Auto-Scaling Group Name", "Deployment Tag Key Name", "Deployment Tag Key Value" all found within the output section of the AWS CFT, they will all be used by the subsequent AWS CFT execution as input parameters.


*  3. Run the AWS Cloud Formation Template to create the AWS Code Pipeline, Build and Deploy Stages

The important parameters required to exist in order for this AWS ALB/ASG/LCFG/EC2 created resources to integrate with the overall infrastructure:

| AWS CFT Parameter      | Description |
| ------------- | ----------- |
| **pS3StagingBucketName** | Obtained from the previous invocation of the CFT for the creation of the AWS S3 Bucket creation
| **pApplicationName** | Very Important: Unique Name to be used across multiple invocations of the AWS Cloud Formation Template to create unique resource names related to this deployment infrastructure
| **pAutoScalingGroupName** | Very Important: Name of the AWS Auto-Scaling group involved with the AWS EC2 deployment. obtained from the previous invocation of the CFT for the creation of the AWS ALB/ASG/LCFG/EC2
| **pDeploymentTagKey** | Very Important: Used for the EC2 Deployment Tag Name, obtained from the previous invocation of the CFT for the creation of the AWS ALB/ASG/LCFG/EC2  
| **pDeploymentTagValue** | Very Important: Used for the EC2 Deployment Tag Value, obtained from the previous invocation of the CFT for the creation of the AWS ALB/ASG/LCFG/EC2
| **pExecuteDeployStage** | Very Important: Depending on the value provided, the pipeline skips/continues to deployment stage. Deployment resources will be skipped from provisioning if 'skip' is selected
| **pPgeOrderNum** | Organization Project Charge Code Number (e.g. 70036060)
| **pPgeAppId** | Used for tagging assets created by the template.  The AppID tag is the value in 'APP-#### format that represents the AMPS record that this resource is associated with.  The AppID value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeOwner** | Used for tagging assets created by the template.  The Owner tag is the 4 digit Lan ID of the person directly responsible for this resource as recorded in AMPS.  In many cases this is the director or other leader responsible for the application that owns the resource.  The owner value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings.
| **pPgeNotify** | Used for tagging assets created by the template. The Notify tag is the email address of the person or distribution list that would be notified in the event that there are isssues with this resource.  The notify value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeEnv** | Used for tagging assets created by the template.  The Environemnt tag is simply 'DEV', 'TEST', 'QA', or 'PROD' indicating the type of environment that this resource will be created in.  The environment value is populated from the account level values stored in Parameter Store.  There is no need to update this value unless you would like to override the account level settings
| **pPgeDataClassification** | Used for tagging assets created by the template. Data Classification - Please validate your input value with AMPS
| **pCompliance** | Used for tagging assets created by the template.  Compliance Requirements - Please validate your input value with AMPS
| **pPgeCrisScore** | Used for tagging assets created by the template.  Cyber Risk Impact Score (CRIS) - Please validate your input value with AMPS
| **pPgeBusinessImpact** | Business Impact as reflective of the BIA
| **pPgeLandingZone** | Is this a Cloud CoE Landing Zone resource ("true" or "false")

* **Important aspects of the AWS Code Deploy configuration**

* 1. It is based on a "KEY_AND_VALUE" AWS EC2 instance deployment where the AWS EC2 instances managed by the auto-scaling group for AWS Code Deployment are designated with certain customer-defined resource tags.

* 2. The AWS Code Deploy configuration uses the "MinimumHealthyHosts" attribute.

**MinimumHealthyHosts:
  Type: !Ref pMinHealthType
  Value: !Ref pMinHealthValue**

* 3. Ensure the **appspec.yml** is updated correctly and resides within the root directory of the source GitHub repository.  This file is used by the AWS Code Deploy service for performing the exection of the deployment strategy.

## References

* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

## Authored By
* Chris Grassi - Cloud Platform Engineer - PG&E
