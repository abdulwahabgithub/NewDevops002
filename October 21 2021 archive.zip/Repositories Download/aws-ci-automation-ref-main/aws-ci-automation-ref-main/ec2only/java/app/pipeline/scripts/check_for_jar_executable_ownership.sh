#!/bin/bash -xv

# Check for the existence and ownership of the Java Jar executable file  e.g. "spring-boot-lambda-1.0.0-SNAPSHOT.jar" and set ownership if necessary.

export APP_DIRECTORY="/var/opt/spring-boot"
export JAR_FILE_NAME="spring-boot-lambda.jar"
export USER_OWNERSHIP="spring-boot"
export GROUP_OWNERSHIP="spring-boot"
export CURRENT_USER_OWNERSHIP=""
export CURRENT_GROUP_OWNERSHIP=""

if [ -f ${APP_DIRECTORY}/${JAR_FILE_NAME} ]
then
  chmod 755
  CURRENT_USER_OWNERSHIP=$(stat -c '%U' $APP_DIRECTORY/${JAR_FILE_NAME})
  CURRENT_GROUP_OWNERSHIP=$(stat -c '%G' $APP_DIRECTORY/${JAR_FILE_NAME})
  if [ "${CURRENT_USER_OWNERSHIP}" != "${USER_OWNERSHIP}" ]
  then
    chown -R ${USER_OWNERSHIP}:${GROUP_OWNERSHIP} ${APP_DIRECTORY}/${JAR_FILE_NAME}
  fi

  if [ "${CURRENT_GROUP_OWNERSHIP}" != "${GROUP_OWNERSHIP}" ]
  then
    chown -R ${USER_OWNERSHIP}:${GROUP_OWNERSHIP} ${APP_DIRECTORY}/${JAR_FILE_NAME}
  fi
else
  echo "Do nothing...."
fi
