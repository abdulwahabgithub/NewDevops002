# Instructions: Install and configure a reference implementation for the BLUE-GREEN deployment of an application serving using an AWS ALB, Weighted Target Groups associated with AWS ASGs for a canary-style cutover.


## Overview

This is a set of written instructions to set up and configure an AWS ALB with an weighted target groups that will integrate with AWS ASGs in a BLUE-GREEN deployment configuration using a canary style cutover.

## The AWS ALB, VPC, Target Group and ASG architectural configuration illustration

![alt text](./AlbWtgsAsgs1.png "AWS ALB, VPC, Target Group and ASG Blue-Green Deployment Architecture Illustration Part 1")

![alt text](./AlbWtgsAsgs2.png "AWS ALB, VPC, Target Group and ASG Blue-Green Deployment Architecture Illustration Part 2")

## Prerequisites
* **Required AWS Cloud Formation templates**
* AWS Cloud Formation template to create a SAFE 2.0 compliant AWS ALB
* **AWS ALB Cloud Formation Template:** [AWS ALB CFT](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-285/blue-green-ec2/deploy-blue-green-alb.yml)
* AWS Cloud Formation template to create a SAFE 2.0 AWS ACM X.509 Certificate
* **AWS ACM X.509 Cloud Formation Template:** [AWS ACM X.509 Certificate CFT](https://github.com/pgetech/aws-cfn-certificate/blob/master/aws-cfn-certificate-single.yml)
* AWS Cloud Formation template to create a SAFE 2.0 compliant AWS ALB Listener, Rules and Target Groups
* **AWS ALB Listener, Listener Rule and Weighted Target Group Cloud Formation Template:** [AWS ALB Listner, Listener Rule and Target Groups](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-285/blue-green-ec2/Deploy-Blue-Green-Target-Groups-ALB-Listener.yml)
* AWS Cloud Formation template to create a SAFE 2.0 compliant AWS EC2 Launch Template and ASG
* **AWS EC2 Lauch Template and ASG:** [AWS EC2 Launch Template and ASG CFT](https://github.com/pgetech/aws-ci-automation-ref/blob/c1gx/CLOUDCOE-285/blue-green-ec2/Deploy-Blue-Green-LT-ASG.yml)

## The AWS ALB, ALB Listener, ALB Listener Rule and Weighted Target Group Overall Concepts and Considerations

## How you will build it
**Section 1: Create an AWS ALB using Cloud Formation**
* 1. Create an AWS ALB using the AWS Cloud Formation Template referenced above.

* 2. Record the ARN of the AWS ALB that is generated within the output section of the cloud formation template.

* 3. Record the DNS alias entry for the AWS ALB that is generated within the output section of the cloud formation template.

**Section 2: Configure a CNAME record and associate it with an ALIAS record that corresponds to the DNS Alias of the AWS ALB**

* 1. Go to the AWS Route 53 DNS service and create a CNAME record (e.g. deploy-bg.nonprod.pge.com) and associate it with the DNS alias entry for the AWS ALB that was generated within the output section of the cloud formation template.

**Section 3: Generate an AWS ACM X.509 Certificate using Cloud Formation**

* 1. Create an AWS ACM X.509 Certificate using the AWS Cloud Formation Template referenced above.

Important: When referencing the Hosted Zone ID within the cloud formation template, be sure to use the one dedicated for ACM use only.

* 2. Record the ARN of the AWS ACM X.509 Certifacte that is generated within the output section of the cloud formation template.

**Section 4: Generate the AWS ALB Listener, Listener Rule, and Target Groups using Cloud Formation**

* Create the AWS ALB Listener, Listener Rule, and Target Groups using the AWS Cloud Formation Template referenced above.

Obtain the AWS ALB ARN, the AWS ACM ARN from the output sections of the respective cloud formation templates

* 1. Set the relative weights of each target group that correspond to the intended blue-green deployment mode and canary style deployment.

* 2. Enable/disable sticky session and set duration (e.g. 1 min, 5 min, 10 min etc.) if relevant.

* 3. Set default target group within the default listener rule.

* 4. Record the ARNs of the Target Groups from the output sections of the respective cloud formation template.

**Section 5: Generate the AWS EC2 Launch Template and ASG for the Blue and Green Deployment Groups using Cloud Formation**

*Create the AWS EC2 Launch Template and Auto-scaling Group (ASG) for each of the Blue and Green deployment groups using the AWS Cloud Formation Template referenced above.

Note: Create the Blue Deployment Group first and then the Green Deployment after using a separate cloud formation stack for each.

* 1. Obtain the ARN of the Target Group that corresponds to each deployment group (e.g. Blue or Green) from the output section of the cloud formation template used to create the ALB Target Groups.


## References

* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

* [AWS ALB User Guide](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/introduction.html)

* [AWS ACM User Guide](https://docs.aws.amazon.com/acm/latest/userguide/acm-overview.html)

* [AWS ASG User Guide](https://docs.aws.amazon.com/autoscaling/ec2/userguide/what-is-amazon-ec2-auto-scaling.html)

## Authored By
* Chris Grassi - Cloud Platform Engineer - PG&E
