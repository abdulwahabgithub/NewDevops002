#!/bin/bash

set -xv


export ROLE_CODEBUILD="${SERVICE_ROLE_CODEBUILD}"
kubectl get -n kube-system configmap/aws-auth -o yaml > a.out
ROLE="    - rolearn: ${ROLE_CODEBUILD}\n      username: admin\n      groups:\n        - system:masters"
Filename="a.out"
if grep -q ${ROLE_CODEBUILD} "${Filename}"; then
  echo " already exist"
else
kubectl get -n kube-system configmap/aws-auth -o yaml | awk "/mapRoles: \|/{print;print \"${ROLE}\";next}1" > /tmp/aws-auth-patch.yml
kubectl patch configmap/aws-auth -n kube-system --patch "$(cat /tmp/aws-auth-patch.yml)"
fi