#!/usr/bin/env python
"""HealthCheck Service"""
import os
import boto3
import requests

# SECOND UPDATE 
####
def check_url(arg_url):

    client = boto3.client('ssm')
    apikey = client.get_parameter(Name='/operations/raisealert/x-api-key')
    print(apikey['Parameter']['Value'])

    posturl = client.get_parameter(Name='/operations/raisealert/api-endpoint')
    print(posturl['Parameter']['Value'])

    ep_blah = client.get_parameter(Name='/operations/raisealert/api-path')
    print(ep_blah['Parameter']['Value'])

    finalurl = "https://" + posturl['Parameter']['Value'] + ep_blah['Parameter']['Value']
    print(finalurl)
    try:
        requests.get(arg_url, verify=False)
        print("{} is currently up -- PTS6!".format(arg_url))
        return True
    except Exception as ex:

        print("{} is not up!".format(arg_url))
        print("Exception: {}".format(ex))

        alert_info = {
            "Message": "CICD-CODEPIPELINE-100",
            "Severity": "MAJOR",
            "Description": "{} CICD Pipelie Service is not up".format(arg_url),
            "Product-Service": "Application service raised this alert",
            "Action": "Please reach out to CCOE OnCall Support",
            "Destination": "ALL"
        }
        print('ABOUT to send alert to ENOC since app svc seems not reachable')
        headers = {"Content-Type": "application/json",
                   "x-api-key": apikey['Parameter']['Value'],
                   "Host": posturl['Parameter']['Value']}
        try:
            print("Before invoke raiseAlert call for Notification")
            resp = requests.post(finalurl, json=alert_info, headers=headers)
            print("After invoke raiseAlert call for Notification")
            print(resp)
            print(resp.status_code)
            return True

        except Exception as ex:
            print("Exception: {}".format(ex))
            #if resp.status_code != 200:
              #Raise ApiError('POST /RaiseAlert failed{}'.format(resp.status_code))

    return False

def lambda_handler(event, context):
    check_url(os.environ['jfrogURL'])
