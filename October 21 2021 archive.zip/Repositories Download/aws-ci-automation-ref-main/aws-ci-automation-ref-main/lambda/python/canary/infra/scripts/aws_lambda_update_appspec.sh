#/bin/sh

#--------------------------------------------------#
#  File: aws_lambda_update_appspec.sh              #
#  Date: 2020-12-21                                #
#  Author: Chris Grassi (c1gx@pge.com)             #
#                                                  #
#  Script to create or update and deploy an        #
#  AWS Lambda function using the AWS CLI and       #
#  AWS Code Deploy from the AWS Build Stage of     #
#  an AWS Code Pipeline                            #
#--------------------------------------------------#


set -xv

# Initialize Global Variables
# ---------------------------
export SUB_FOLDER="lambda/python/canary/app"
export BASE_DIR="${CODEBUILD_SRC_DIR}/${SUB_FOLDER}"
export AWS_LAMBDA_FUNCTION_ARN=""
export AWS_LAMBDA_CURRENT_VERSION=""
export AWS_LAMBDA_PUBLISHED_VERSION_NEW=""
export AWS_LAMBDA_PUBLISHED_VERSION_CURRENT=""
export DEPLOY_APPSPEC_YAML="appspec.yml"
export LAMBDA_FUNCTION_ALIAS_ARN=""
export PREVIOUS_CODEBUILD_BUILD_ID=""
export PREVIOUS_CODEBUILD_BUILD_NUMBER=""
export PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION=""
export PREVIOUS_CODEBUILD_STATUS=""
export LIST_OF_BUILD_IDS_BY_PROJECT=""
export LIST_OF_SUCCESSFUL_BUILD_IDS_FOR_PROJECT=""
export NO_OF_SUCCESSFUL_BUILD_IDS=0
export VPC_CONFIG_JSON=""
export LAMBDA_ENV_VARIABLES_JSON=""
export LAMBDA_TAGS_JSON=""
export AWS_LAMBDA_FUNCTION_EXISTS="0"
declare -a array_of_build_ids_succeeded=()

# Print imported environmental Variables
# --------------------------------------
echo "Printing all of the imported BASH Shell enironmental variables..."
echo "AWS_VPC_ID - ${AWS_VPC_ID}"
echo "AWS_SUBNET_A - ${AWS_SUBNET_A}"
echo "AWS_SUBNET_B - ${AWS_SUBNET_B}"
echo "AWS_SUBNET_C - ${AWS_SUBNET_C}"
echo "AWS_LAMBDA_DESCRIPTION - ${AWS_LAMBDA_DESCRIPTION}"
echo "AWS_STACK_NAME - ${AWS_STACK_NAME}"
echo "AWS_LAMBDA_FUNCTION_CODE_FILENAME - ${AWS_LAMBDA_FUNCTION_CODE_FILENAME}"
echo "AWS_LAMBDA_FUNCTION_HANDLER - ${AWS_LAMBDA_FUNCTION_HANDLER}"
echo "AWS_LAMBDA_SG - ${AWS_LAMBDA_SG}"
echo "AWS_LAMBDA_FUNCTION_ALIAS - ${AWS_LAMBDA_FUNCTION_ALIAS}"
echo "AWS_S3_STAGING_BUCKET - ${AWS_S3_STAGING_BUCKET}"
echo "AWS_CODE_DEPLOY_ROLE_NAME - ${AWS_CODE_DEPLOY_ROLE_NAME}"
echo "AWS_CODE_DEPLOY_APPNAME - ${AWS_CODE_DEPLOY_APPNAME}"
echo "AWS_CODE_DEPLOY_GROUPNAME - ${AWS_CODE_DEPLOY_GROUPNAME}"
echo "AWS_CODE_DEPLOY_CONFIG - ${AWS_CODE_DEPLOY_CONFIG}"
echo "AWS_CODE_DEPLOY_ROLE_ARN - ${AWS_CODE_DEPLOY_ROLE_ARN}"
echo "AWS_CODE_BUILD_PROJECT_NAME - ${AWS_CODE_BUILD_PROJECT_NAME}"
echo "ENV_KEY - ${ENV_KEY}"
echo "ENV_VALUE - ${ENV_VALUE}"
echo "JFROG_URL_KEY - ${JFROG_URL_KEY}"
echo "JFROG_URL_VALUE - ${JFROG_URL_VALUE}"
echo "AWS_LAMBDA_MEMORY_SIZE - ${AWS_LAMBDA_MEMORY_SIZE}"
echo "AWS_LAMBDA_TIMEOUT - ${AWS_LAMBDA_TIMEOUT}"
echo "AWS_LAMBDA_SERVICE_ROLE_ARN - ${AWS_LAMBDA_SERVICE_ROLE_ARN}"
echo "AWS_LAMBDA_RUNTIME - ${AWS_LAMBDA_RUNTIME}"
echo "AWS_LAMBDA_KEY_ALIAS - ${AWS_LAMBDA_KEY_ALIAS}"
echo "PGE_NAME_TAG - ${PGE_NAME_TAG}"
echo "PGE_OWNER_TAG - ${PGE_OWNER_TAG}"
echo "PGE_NOTIFY_TAG - ${PGE_NOTIFY_TAG}"
echo "PGE_APPID_TAG - ${PGE_APPID_TAG}"
echo "PGE_ORDER_TAG - ${PGE_ORDER_TAG}"
echo "PGE_DATACLASS_TAG - ${PGE_DATACLASS_TAG}"
echo "PGE_COMPLIANCE_TAG - ${PGE_COMPLIANCE_TAG}"
echo "PGE_BUSINESS_IMPACT_TAG - ${PGE_BUSINESS_IMPACT_TAG}"
echo "PGE_CRIS_SCORE_TAG - ${PGE_CRIS_SCORE_TAG}"
echo "PGE_LANDING_ZONE_TAG - ${PGE_LANDING_ZONE_TAG}"
echo "DEBUG - ${DEBUG}"
cho "CODEBUILD_RESOLVED_SOURCE_VERSION - ${CODEBUILD_RESOLVED_SOURCE_VERSION}"
echo "CODEBUILD_BUILD_ID - ${CODEBUILD_BUILD_ID}"
echo "CODEBUILD_BUILD_NUMBER - ${CODEBUILD_BUILD_NUMBER}"

# Function get previous build run information

function get_previous_build_run_info() {
  PREVIOUS_CODEBUILD_BUILD_ID=""
  PREVIOUS_CODEBUILD_BUILD_NUMBER=""
  PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION=""
  echo "Getting Build Run Information for: $1"
  PREVIOUS_CODEBUILD_BUILD_ID="$1"
  echo "PREVIOUS_CODEBUILD_BUILD_ID - ${PREVIOUS_CODEBUILD_BUILD_ID}"
  PREVIOUS_CODEBUILD_BUILD_NUMBER=$(aws codebuild batch-get-builds --ids ${PREVIOUS_CODEBUILD_BUILD_ID} | jq -r '.builds [].buildNumber')
  echo "PREVIOUS_CODEBUILD_BUILD_NUMBER - ${PREVIOUS_CODEBUILD_BUILD_NUMBER}"
  PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION=$(aws codebuild batch-get-builds --ids ${PREVIOUS_CODEBUILD_BUILD_ID} | jq -r '.builds [].resolvedSourceVersion')
  echo "PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION - ${PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION}"
}

# Function to generate the appspec.yml file as a here document
function generate_appspec_yml () {
  echo "Generating DEPLOY_APPSPEC_YAML: ${BASE_DIR}/$DEPLOY_APPSPEC_YAML"
  echo "version: 0.0" > ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "Resources:" >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "  - ${AWS_LAMBDA_FUNCTION_CODE_FILENAME}:" >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "      Type: AWS::Lambda::Function"  >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "      Properties:" >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "        Name: \"${AWS_LAMBDA_FUNCTION_CODE_FILENAME}\""  >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "        Alias: \"${AWS_LAMBDA_FUNCTION_ALIAS}\"" >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "        CurrentVersion: \"${AWS_LAMBDA_PUBLISHED_VERSION_CURRENT}\"" >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
  echo "        TargetVersion: \"${AWS_LAMBDA_PUBLISHED_VERSION_NEW}\""  >> ${BASE_DIR}/$DEPLOY_APPSPEC_YAML
}

# Checking to see if the AWS Lambda function exists
# -------------------------------------------------

AWS_LAMBDA_FUNCTION_EXISTS=$(aws lambda get-function --function-name "${AWS_LAMBDA_FUNCTION_CODE_FILENAME}" | jq -r '.Configuration.FunctionArn' | wc -w |  sed 's/^[[:space:]]*//g')
echo "AWS_LAMBDA_FUNCTION_EXISTS: ${AWS_LAMBDA_FUNCTION_EXISTS}"

# Process Build ID information Section
# ------------------------------------
echo "Getting list of builds for project - ${AWS_CODE_BUILD_PROJECT_NAME}"
LIST_OF_BUILD_IDS_BY_PROJECT=$(aws codebuild list-builds-for-project --project-name "${AWS_CODE_BUILD_PROJECT_NAME}" --sort-order DESCENDING | jq -r '.ids []')
echo "LIST_OF_BUILD_IDS_BY_PROJECT: ${LIST_OF_BUILD_IDS_BY_PROJECT}"
echo "Getting list of successful builds for project - ${AWS_CODE_BUILD_PROJECT_NAME}"

#LIST_OF_SUCCESSFUL_BUILD_IDS_FOR_PROJECT=$(aws codebuild batch-get-builds --ids ${LIST_OF_BUILD_IDS_BY_PROJECT} | jq -r '.builds [] | select(.buildStatus == "SUCCEEDED") | .id')
NO_OF_SUCCESSFUL_BUILD_IDS=$(aws codebuild batch-get-builds --ids ${LIST_OF_BUILD_IDS_BY_PROJECT} | jq -r '.builds [] | select(.buildStatus == "SUCCEEDED") | .id' | wc -l)

echo "LIST_OF_SUCCESSFUL_BUILD_IDS_FOR_PROJECT - ${LIST_OF_SUCCESSFUL_BUILD_IDS_FOR_PROJECT}"
echo "NO_OF_SUCCESSFUL_BUILD_IDS - ${NO_OF_SUCCESSFUL_BUILD_IDS}"

if [ ${NO_OF_SUCCESSFUL_BUILD_IDS} -ge 1 ]
then
  LIST_OF_SUCCESSFUL_BUILD_IDS_FOR_PROJECT=$(aws codebuild batch-get-builds --ids ${LIST_OF_BUILD_IDS_BY_PROJECT} |  jq -r '[ .builds [] | select(.buildStatus == "SUCCEEDED") | .id ] | .[0]')
  read -a array_of_build_ids_succeeded <<< ${LIST_OF_SUCCESSFUL_BUILD_IDS_FOR_PROJECT}
else
  array_of_build_ids_succeeded=()
fi

echo "array_of_build_ids_succeeded - ${#array_of_build_ids_succeeded[@]}"

if [[ ( ${#array_of_build_ids_succeeded[@]} -eq 0 ) && ( "$AWS_LAMBDA_FUNCTION_EXISTS" == "0" ) ]]
then
  AWS_LAMBDA_CURRENT_VERSION=""
  echo "Initial deployment of AWS Lambda Function: ${AWS_STACK_NAME}"
  LAMBDA_ENV_VARIABLES_JSON="{\"Variables\":{\"$ENV_KEY\":\"$ENV_VALUE\",\"$JFROG_URL_KEY\":\"$JFROG_URL_VALUE\"}}"
  echo "LAMBDA_ENV_VARIABLES_JSON - ${LAMBDA_ENV_VARIABLES_JSON}"
  VPC_CONFIG_JSON="{\"SubnetIds\":[\"$AWS_SUBNET_A\",\"$AWS_SUBNET_B\",\"$AWS_SUBNET_C\"],\"SecurityGroupIds\":[\"$AWS_LAMBDA_SG\"]}"
  echo "VPC_CONFIG_JSON - ${VPC_CONFIG_JSON}"
  LAMBDA_TAGS_JSON="{\"Name\":\"${PGE_NAME_TAG}\",\"Owner\":\"$PGE_OWNER_TAG\",\"Notify\":\"$PGE_NOTIFY_TAG\",\"AppID\":\"$PGE_APPID_TAG\",\"Environment\":\"$PGE_ENV_TAG\",\"Order\":\"$PGE_ORDER_TAG\",\"DataClassification\":\"$PGE_DATACLASS_TAG\",\"Compliance\":\"$PGE_COMPLIANCE_TAG\",\"BusinessImpact\":\"$PGE_BUSINESS_IMPACT_TAG\",\"CRIS\":\"$PGE_CRIS_SCORE_TAG\",\"LandingZone\":\"$PGE_LANDING_ZONE_TAG\"}"
  echo "LAMBDA_TAGS_JSON - ${LAMBDA_TAGS_JSON}"

  if [ -f "${BASE_DIR}/${AWS_LAMBDA_FUNCTION_CODE_FILENAME}.zip" ]
  then
    AWS_LAMBDA_CURRENT_VERSION=$(aws lambda create-function \
        --function-name "${AWS_LAMBDA_FUNCTION_CODE_FILENAME}" \
        --description "${AWS_LAMBDA_DESCRIPTION}" \
        --runtime "${AWS_LAMBDA_RUNTIME}" \
        --memory-size "${AWS_LAMBDA_MEMORY_SIZE}" \
        --timeout "${AWS_LAMBDA_TIMEOUT}" \
        --kms-key-arn "${AWS_LAMBDA_KEY_ALIAS}" \
        --zip-file "fileb://${BASE_DIR}/${AWS_LAMBDA_FUNCTION_CODE_FILENAME}.zip" \
        --handler "${AWS_LAMBDA_FUNCTION_HANDLER}" \
        --role "${AWS_LAMBDA_SERVICE_ROLE_ARN}" \
        --vpc-config "${VPC_CONFIG_JSON}" \
        --environment "${LAMBDA_ENV_VARIABLES_JSON}" \
        --tags "$LAMBDA_TAGS_JSON" \
        --publish | jq -r '.Version')
  else
     echo "Zip File: ${BASE_DIR}/${AWS_LAMBDA_FUNCTION_CODE_FILENAME}.zip not found..exiting creation of function."
     exit 0
  fi

  #AWS_LAMBDA_CURRENT_VERSION=$(aws lambda get-function --function-name ${AWS_LAMBDA_FUNCTION_CODE_FILENAME} | jq -r '.Configuration.Version')
  LAMBDA_FUNCTION_ALIAS_ARN=$(aws lambda create-alias --function-name ${AWS_LAMBDA_FUNCTION_CODE_FILENAME} --description "alias for live version of function"  --function-version "${AWS_LAMBDA_CURRENT_VERSION}" --name "${AWS_LAMBDA_FUNCTION_ALIAS}" | jq -r '.AliasArn')

  echo "AWS_LAMBDA_CURRENT_VERSION - ${AWS_LAMBDA_CURRENT_VERSION}"
  echo "LAMBDA_FUNCTION_ALIAS_ARN - ${LAMBDA_FUNCTION_ALIAS_ARN}"

elif [[ ( ${#array_of_build_ids_succeeded[@]} -ge 1 ) && ( "$AWS_LAMBDA_FUNCTION_EXISTS" == "1" ) ]]
then
  AWS_LAMBDA_ALIAS_QUERY=
  AWS_LAMBDA_PUBLISHED_VERSION_NEW=""
  AWS_LAMBDA_PUBLISHED_VERSION_CURRENT=""
  AWS_CODE_DEPLOY_GROUP_QUERY=""

  echo "Update of AWS Lambda Function: ${AWS_STACK_NAME}"

  if [ "${array_of_build_ids_succeeded[0]}" != "${CODEBUILD_BUILD_ID}" ]
  then
    echo "Examining Build ID - ${array_of_build_ids_succeeded[0]}"
    get_previous_build_run_info "${array_of_build_ids_succeeded[0]}"

    if [[ ( -n "${PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION}" ) &&  ( "${PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION}" != "${CODEBUILD_RESOLVED_SOURCE_VERSION}" ) ]]
    then
      # Check that alias exists....
      AWS_LAMBDA_ALIAS_QUERY=$(aws lambda list-aliases --function-name ${AWS_LAMBDA_FUNCTION_CODE_FILENAME}  | jq -cr '.Aliases[].Name' | grep ${AWS_LAMBDA_FUNCTION_ALIAS} | wc -l)
      echo "AWS_LAMBDA_ALIAS_QUERY - ${AWS_LAMBDA_ALIAS_QUERY}"

      if [ "${AWS_LAMBDA_ALIAS_QUERY}" == "1" ]
      then
        AWS_LAMBDA_PUBLISHED_VERSION_CURRENT=$(aws lambda get-alias --function-name ${AWS_LAMBDA_FUNCTION_CODE_FILENAME} --name ${AWS_LAMBDA_FUNCTION_ALIAS}  | jq -cr '.FunctionVersion')
      else
        echo "AWS Lambda alias: ${AWS_LAMBDA_FUNCTION_ALIAS} - does not exist...exiting the program."
        exit 1
      fi

      if [ -f "${BASE_DIR}/${AWS_LAMBDA_FUNCTION_CODE_FILENAME}.zip" ]
      then
        AWS_LAMBDA_PUBLISHED_VERSION_NEW=$(aws lambda update-function-code --function-name ${AWS_LAMBDA_FUNCTION_CODE_FILENAME} --zip-file fileb://${BASE_DIR}/${AWS_LAMBDA_FUNCTION_CODE_FILENAME}.zip --publish | jq -r '.Version')
      else
        echo "Zip File: ${BASE_DIR}/${AWS_LAMBDA_FUNCTION_CODE_FILENAME}.zip not found..exiting update of function."
        exit 0
      fi

      echo "AWS_LAMBDA_PUBLISHED_VERSION_CURRENT - ${AWS_LAMBDA_PUBLISHED_VERSION_CURRENT}"
      echo "AWS_LAMBDA_PUBLISHED_VERSION_NEW - ${AWS_LAMBDA_PUBLISHED_VERSION_NEW}"

      echo "Generating a new and/or updated version of the DEPLOY_APPSPEC_YAML ${DEPLOY_APPSPEC_YAML}"
      generate_appspec_yml
      echo "Copy DEPLOY_APPSPEC_YAML: ${BASE_DIR}/$DEPLOY_APPSPEC_YAML to AWS S3 Bucket ${AWS_S3_STAGING_BUCKET} with Object Key ${DEPLOY_APPSPEC_YAML}"
      aws s3 cp ${BASE_DIR}/${DEPLOY_APPSPEC_YAML} s3://${AWS_S3_STAGING_BUCKET}/${DEPLOY_APPSPEC_YAML} --acl bucket-owner-full-control
      echo "Check to see if there is an existing AWS Code Deployment Group"

      AWS_CODE_DEPLOY_GROUP_QUERY=$(aws deploy get-deployment-group --application-name ${AWS_CODE_DEPLOY_APPNAME} --deployment-group-name ${AWS_CODE_DEPLOY_GROUPNAME} | jq -r  '.deploymentGroupInfo.deploymentGroupName' | sed 's/^[[:space:]]*//g')

      if [ "${AWS_CODE_DEPLOY_GROUP_QUERY}" != "${AWS_CODE_DEPLOY_GROUPNAME}" ]
      then
        echo "Creating AWS Code Deploy Group: ${AWS_CODE_DEPLOY_GROUPNAME}"
        AWS_CODE_DEPLOY_GROUPID=$(aws deploy create-deployment-group --application-name ${AWS_CODE_DEPLOY_APPNAME} --deployment-group-name ${AWS_CODE_DEPLOY_GROUPNAME}  --deployment-config-name ${AWS_CODE_DEPLOY_CONFIG} --deployment-style \{\"deploymentType\":\"BLUE_GREEN\",\"deploymentOption\":\"WITH_TRAFFIC_CONTROL\"\}  --service-role-arn ${AWS_CODE_DEPLOY_ROLE_ARN} | jq -r .deploymentGroupId | sed 's/^[[:space:]]*//g')
        echo "AWS_CODE_DEPLOY_GROUPID: ${AWS_CODE_DEPLOY_GROUPID}"
      fi

      DEPLOY_REVISION="revisionType=S3,s3Location={bucket=$AWS_S3_STAGING_BUCKET,key=$DEPLOY_APPSPEC_YAML,bundleType=YAML}"
      echo "Creating AWS Code Deploy: deployment application ${AWS_CODE_DEPLOY_APPNAME}, configuration ${AWS_CODE_DEPLOY_CONFIG} and group name ${AWS_CODE_DEPLOY_GROUPNAME}"
      aws deploy create-deployment --application-name ${AWS_CODE_DEPLOY_APPNAME} --deployment-group-name ${AWS_CODE_DEPLOY_GROUPNAME} --deployment-config-name ${AWS_CODE_DEPLOY_CONFIG} --revision ${DEPLOY_REVISION}
      exit 0
    else
      echo "PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION: ${PREVIOUS_CODEBUILD_RESOLVED_SOURCE_VERSION} and CODEBUILD_RESOLVED_SOURCE_VERSION: ${CODEBUILD_RESOLVED_SOURCE_VERSION} indeterminate or equivalent.."
      echo "exiting the program...."
      exit 0
    fi
  else
    echo "Unable to evaluate most recent Build ID : ${array_of_build_ids_succeeded[0]} for AWS Lambda Function: ${AWS_LAMBDA_FUNCTION_CODE_FILENAME}"
    echo "exiting the program...."
    exit 0
  fi
elif [[ ( ${#array_of_build_ids_succeeded[@]} -ge 1 ) && ( "$AWS_LAMBDA_FUNCTION_EXISTS" == "0" ) ]]
then
  echo "Deployment/Build Status for ${AWS_LAMBDA_FUNCTION_CODE_FILENAME} is indeterminate, exiting the program...."
  exit 0
elif [[ ( ${#array_of_build_ids_succeeded[@]} -ge 0 ) && ( "$AWS_LAMBDA_FUNCTION_EXISTS" == "1" ) ]]
then
  echo "Deployment/Build Status for ${AWS_LAMBDA_FUNCTION_CODE_FILENAME} is indeterminate, exiting the program...."
  exit 0
else
  echo "Deployment/Build Status for ${AWS_LAMBDA_FUNCTION_CODE_FILENAME} is indeterminate, exiting the program...."
  exit 0
fi
