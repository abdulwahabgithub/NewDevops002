All folder have reference implementations of CICD pipeline of various different workloads and different languages.
It's self starter/enabler for anyone to use it for project and have taken away most of the complexity. You will still need to clone/duplicate & modify for your own application needs.
 

Note: All attempt has been made to stay in-sync with SAF2.0 controls of AWS resources.
If you find missing; Please contribute by submitting PR and/or open issue so it can be added.
 
Then what we have in each folder - such as
ec2only is for EC2 based deployment
containers is for container workload - kubernete (k8s)
and lambda as serverless (including example of SAM based deployment supporting linear and/or canary style deployments)