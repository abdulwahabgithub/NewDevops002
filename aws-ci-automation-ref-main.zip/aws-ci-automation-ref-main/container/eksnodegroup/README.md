<<<<<<< HEAD
# AWS EKS Node Group:

# Instructions: AWS cloudformation template to provision an EKS Node Group for Elastic Container Service for Kubernetes.

Instantiate it multiple times to create many EKS node groups with specific settings such as GPUs, EC2 instance types, or autoscale parameters.

# Prerequisites:

AWS Cloud Formation template to create a SAFE 2.0 compliant AWS EKS Cluster creation to join nodes.
You can also use the AWS CloudFormation templates as a starting point for your own implementation.
Same role we need to use

Step1:
* launch node group using cloudformation template
https://github.com/pgetech/aws-ci-automation-ref/blob/r4tn/CLOUDCOE-92/container/eksnodegroup/eks-nodegroup.yaml

Step2:
when nodegroup template got created. You will findout eks workerrole arn in cloudformation outputs tab. we need to use this arn top join with EKS cluster using aws-auth file.

Step3:
* join nodes to the cluster:

# eks master update after kubectl install
aws eks update-kubeconfig --name Cluster-Name --region us-west-2

### aws auth install for kubectl node arn join
* curl -O https://amazon-eks.s3-us-west-2.amazonaws.com/cloudformation/2018-11-07/aws-auth-cm.yaml
* sed -i "s|<ARN of instance role (not instance profile)>|$(rEksWorkerRole.Arn)|g" /aws-auth-cm.yaml  ( we need to replace worker role arn $(rEksWorkerRole.Arn) )
* arn you will find cfn node template output 
example:
![image](https://user-images.githubusercontent.com/77122375/109869572-e7377800-7c1d-11eb-9fd4-7bbec50f6269.png)

* kubectl config view
* kubectl cluster-info
# This command with update changes to aws-auth file then nodes will join.
* kubectl apply -f aws-auth-cm.yaml

# Now nodes will join with EKS Cluster you can findout using this command:
* kubectl get nodes --watch

# Now we need to install alb load-balancer-controller:
# check cluster status
* aws eks describe-cluster --name ${pClusterName} --query "cluster.identity.oidc.issuer" --output text
* eksctl utils associate-iam-oidc-provider --cluster ${pClusterName} --approve
* eksctl create iamserviceaccount --cluster=${pClusterName} --namespace=kube-system --name=aws-load-balancer-controller --attach-policy-arn:${rloadbalancerRole.Arn} --override-existing-serviceaccounts --approve
* kubectl apply --validate=false -f https://github.com/jetstack/cert-manager/releases/download/v1.0.2/cert-manager.yaml
* curl -o v2_1_3_full.yaml https://raw.githubusercontent.com/kubernetes-sigs/aws-load-balancer-controller/v2.1.3/docs/install/v2_1_3_full.yaml
# we need to edit v2_1_3_full.yaml file and remove Service Account block, Deployment block Spec: we have update cluster name.
# Now apply using this command
* kubectl apply -f v2_1_3_full.yaml

## -This is prerequisite for codepipeline we need iam role to execute pod deployments-----

# Edit aws-auth-cm.yaml file and add another iam role for codepipeline otherwise codepipeline will failed to deploy pods on eks cluster
* ROLE="    - rolearn: ${ROLE_CODEBUILD}\n      username: admin\n      groups:\n        - system:masters"
* kubectl get -n kube-system configmap/aws-auth -o yaml | awk "/mapRoles: \|/{print;print \"${ROLE}\";next}1" > /tmp/aws-auth-patch.yml
* kubectl patch configmap/aws-auth -n kube-system --patch "$(cat /tmp/aws-auth-patch.yml)"
# check using this command whether its added or not 
* kubectl edit -n kube-system configmap/aws-auth

# Referrence:
https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html

AWS Documentation for EKS Node-Groups:
https://docs.aws.amazon.com/eks/latest/userguide/eks-compute.html

# Authored By:
Rajesh Tadiparthi
=======
# Instructions: This Instructions helps you to deploy a Kubernetes cluster that uses Amazon Elastic Kubernetes Service (Amazon EKS), enabling you to deploy, manage, and scale containerized applications running on Kubernetes on the Amazon Web Services (AWS) Cloud.


# Overview:
Amazon EKS runs the Kubernetes management infrastructure for you across multiple AWS Availability Zones to eliminate a single point of failure. 

You can use the AWS CloudFormation templates included with the Quick Start to deploy an Amazon EKS cluster in your AWS account in about 25 minutes. The Quick Start automates the following:

Deploying Amazon EKS into an existing VPC and Subnets

# EKS Cluster version:
AWS EKS cluster 1.19 version 

Using cloudformation template EKS have issues with tags, control plane logging enabled, private network enabled, Add-on network. we're using lambda function with python script to enable all these tasks for now. when launching cfn template it will takecare of all these. Everytghing is automated.

# Prerequisites:
We need AWS CloudFormation templates as a starting point for your own implementation.

AWS Cloud Formation template to create a SAFE 2.0 compliant EKS Cluster creation.

AWS Cli and Credentials 

## How you will build it

Step1:
## Launch eks template:

* https://github.com/pgetech/aws-ci-automation-ref/blob/r4tn/CLOUDCOE-91/container/ekscluster/eks-cluster.yml

Step2:
# Role based Access:
When we are launching a cluster using a role from our local eks cluster will authenticate with that role. Otherthan this we can't access EKS Cluster first time. We can provide access to the users based on the role arn.

# Docs for eks role access:
* [EKS cluster role based access] (https://docs.aws.amazon.com/eks/latest/userguide/add-user-role.html)

After Launching the cluster using AWS cloudformation template

Step3:
Before joining nodes to the cluster we need to do some configuration stuff for EKS Cluster.

### kubectl install
* curl -o kubectl https://amazon-eks.s3.us-west-2.amazonaws.com/1.18.9/2020-11-02/bin/linux/amd64/kubectl
* curl -o aws-iam-authenticator https://amazon-eks.s3.us-west-2.amazonaws.com/1.18.9/2020-11-02/bin/linux/amd64/aws-iam-authenticator
* chmod +x ./kubectl ./aws-iam-authenticator
* mkdir $HOME/bin
* cp ./kubectl $HOME/bin/kubectl
* cp ./aws-iam-authenticator $HOME/bin
* export PATH=$HOME/bin:$PATH
* echo 'export PATH=$HOME/bin:$PATH' >> ~/.bashrc

# eksctl install
# Linux
* curl --silent --location "https://github.com/weaveworks/eksctl/releases/latest/download/eksctl_$(uname -s)_amd64.tar.gz" | tar xz -C /bin
* eksctl version
# Macos
* /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/master/install.sh)"
* brew tap weaveworks/tap
* brew install weaveworks/tap/eksctl
* brew upgrade eksctl && brew link --overwrite eksctl
* eksctl version

# Important:
* Install AWS Load Balancer Controller this will use when we'are deploying pods and trying to expose an application.

* Follow the instructions below:

* [AWS Load Balancer Controller] https://docs.aws.amazon.com/eks/latest/userguide/aws-load-balancer-controller.html

## References:

* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

* [AWS EKS Cluster Documentation] https://docs.aws.amazon.com/eks/latest/userguide/what-is-eks.html

## Authored By
* Rajesh Tadiparthi
>>>>>>> main
