#!/bin/bash -xv

# Stop application BASH scripts
export APP_NAME="spring-boot-lambda"
export APP_PROCESS_ID=""

APP_PROCESS_ID=$(ps -efl | grep java | grep $APP_NAME | grep -v "grep" | awk '{ print $4}')
APP_PROCESS_ID_WORD_LENGTH=$(echo $APP_PROCESS_ID | wc -w)

if [ ${APP_PROCESS_ID_WORD_LENGTH} -eq 1 ]
then
   kill -9 "${APP_PROCESS_ID}"
fi
