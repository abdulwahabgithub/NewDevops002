#!/bin/bash -xv

# Start application BASH scripts
export APP_NAME="spring-boot-lambda"
export APP_PROCESS_ID=""

APP_PROCESS_ID=$(ps -efl | grep java | grep $APP_NAME | grep -v "grep" | awk '{ print $4}')
APP_PROCESS_ID_WORD_LENGTH=$(echo $APP_PROCESS_ID | wc -w)

if [ ${APP_PROCESS_ID_WORD_LENGTH} -eq 0 ]
then
  nohup java -jar -Dserver.port=8090 /var/opt/spring-boot/spring-boot-lambda.jar > /dev/null 2>&1 &

  APP_PROCESS_ID=$(ps -efl | grep java | grep $APP_NAME | grep -v "grep" | awk '{ print $4}')
  APP_PROCESS_ID_WORD_LENGTH=$(echo $APP_PROCESS_ID | wc -w)

  if [ ${APP_PROCESS_ID_WORD_LENGTH} -eq 1 ]
  then
    exit 0
  else
    exit 1
  fi
fi
