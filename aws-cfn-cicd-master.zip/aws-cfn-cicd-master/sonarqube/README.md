** Provision SonarQube-CE using Cloud Formation **

PRE-REQUISITE

NOTE: Follow tagging standards as documented here for all CFT(s)
https://wiki.comp.pge.com/display/CCE/AWS+Landing+Zone+-+Asset+Tagging+and+Enforcement

* 1. Create SAF 2.0 Compliant AWS ACM X.509 Certificate using the AWS Cloud Formation Template referenced here.
https://github.com/pgetech/aws-cfn-certificate/blob/master/aws-cfn-certificate-shared.yml
Record the ARN of the AWS ACM X.509 Certificate that is generated within the output section of the cloud formation template.
Important: When referencing the Hosted Zone ID within the cloud formation template, be sure to use the one dedicated for ACM use - Private Hosted Zone Only.

* 2. Create SAF 2.0 Compliant AWS RDS Postgres database to store sonarqube results.
https://github.com/pgetech/aws-cfn-aurora-postgres/blob/master/create_aurora_postgres.yaml
Record the Database connection info that is generated within the output section of the cloud formation template.

* 3. Create SAF 2.0 Compliant Application Load Balancer.
https://github.com/pgetech/aws-cfn-cicd/blob/master/jenkins/jenkins-alb.yml
Record the ARN of the AWS ALB that is generated within the output section of the cloud formation template.

* 4. Generate the AWS EC2 Instance (with sonarqube) and ASG using Cloud Formation **
Key Parameter(s)
pOsType - /ami/linux/golden - PG&E provided golden image for EC2 instance
pEbsKeyAlias - /servicekey/ebs - EBS Volume Encryption Key (i.e. CMK)
pVpcId - VPC
pSubnetIdA - Private Subnet 1 ID
pSubnetIdB - Private Subnet 2 ID
pLoadBalancer - ARN of the Application Load Balancer
pDBEndpoint - RDS Aurora Postgres Database Cluster EndPoint URL
pSonarQubeVersion - SonarQube Version to be installed/configured

Once EC2 machine is up & running; You can login using Session Manager
Important: We do not use SSH keys for login into EC2 so do not need to create/assign keypairs and/or allow SSH port

Next Steps:
Configure SAML SSO for Authentication using your AD Configuration. (Needed for first time setup only as information is stored into postgres database)
Note: Ping Profile is required before SAML SSO setup.
https://wiki.comp.pge.com/display/CCE/Sonarqube+SAML+SSO+Configuration (Documented as per NonProd Environment PoC/Pilot effort)

For further details on sonarqube
https://wiki.comp.pge.com/pages/viewpage.action?pageId=85594252

## References

* [AWS CloudFormation User Guide](https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/Welcome.html)

* [AWS Aurora Postgres Database](https://docs.aws.amazon.com/AmazonRDS/latest/AuroraUserGuide/CHAP_GettingStartedAurora.CreatingConnecting.AuroraPostgreSQL.html)

* [AWS ALB User Guide](https://docs.aws.amazon.com/elasticloadbalancing/latest/application/introduction.html)

* [AWS ACM User Guide](https://docs.aws.amazon.com/acm/latest/userguide/acm-overview.html)

* [AWS ASG User Guide](https://docs.aws.amazon.com/autoscaling/ec2/userguide/what-is-amazon-ec2-auto-scaling.html)

* [AWS EC2 User Guide](https://docs.aws.amazon.com/AWSEC2/latest/UserGuide/EC2_GetStarted.html)

* [SonarQube User Guide](https://docs.sonarqube.org/latest/setup/overview/)


## Authored By
* Piyush Shah - Principal Cloud Platform Architect - PG&E
